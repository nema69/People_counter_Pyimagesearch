# mobilenet_ssd_pedestrian_detection
Mobilenet SSD based pedestrian detection.

[![IMAGE ALT TEXT HERE](http://img.youtube.com/vi/7mBVmek8gLU/0.jpg)](http://www.youtube.com/watch?v=7mBVmek8gLU)

[![IMAGE ALT TEXT HERE](http://img.youtube.com/vi/JiF8NGWE1fU/0.jpg)](http://www.youtube.com/watch?v=JiF8NGWE1fU)

# Training information
* Dataset: Caltech Pedestrian dataset
* Caffe Mobilenet SSD: [https://github.com/chuanqi305/MobileNet-SSD](https://github.com/chuanqi305/MobileNet-SSD)
